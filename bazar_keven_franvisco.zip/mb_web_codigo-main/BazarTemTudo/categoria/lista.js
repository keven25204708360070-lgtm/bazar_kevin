$(function() {

    // Acionar indicativo de carregamento
    $(".spinner-border").css({display: "block"});

    const modal = new bootstrap.Modal('#modal', {});

    $.ajax({
        type: "GET",
        url: "/BazarTemTudo/categoria/obterCategorias.php",
        dataType: "json",
        success: (categorias) => {
            $(".spinner-border").css({display: "none"});
            categorias.forEach(categoria => adicionarLinhaNaTabela(categoria));
        },
        error: () => {
            $(".spinner-border").css({display: "none"});
            $("#mensagemModal").text("Erro ao consultar categorias!");
            modal.show();
            $("<p>").text("Erro ao carregar categorias").appendTo("#corpoTabela");
        }
    });

    $("#adicionar").click(function() {
        $.ajax({
            type: "POST",
            url: "/BazarTemTudo/categoria/adicionar.php",
            dataType: "json",
            data: { descricao: $("#descricao").val() },
            success: categoria => {
                $("#descricao").val("");
                adicionarLinhaNaTabela(categoria);
                $("#mensagemModal").text("Categoria adicionada com sucesso!");
                modal.show();
            },
            error: () => {
                $("#mensagemModal").text("Erro ao adicionar categoria!");
                modal.show();
            }
        });
    });

    $("#alterar").click(() => {
        const id_categoria = $("#idCategoriaParaAlterar").val();
        const descricao = $("#descricaoParaAlterar").val();

        $.ajax({
            type: "POST",
            url: "/BazarTemTudo/categoria/alterar.php",
            dataType: "json",
            data: { id_categoria, descricao },
            success: data => {
                $("#categoria_descricao_" + id_categoria).text(data.descricao);
                $("#mensagemModal").text("Categoria alterada com sucesso!");
                modal.show();
            },
            error: () => {
                $("#mensagemModal").text("Erro ao alterar categoria!");
                modal.show();
            }
        });
    });
});

function iniciarAlterar(id, descricao) {
    $("#idCategoriaParaAlterar").val(id);
    $("#descricaoParaAlterar").val(descricao);
    const modal = new bootstrap.Modal('#modalAlteracao', {});
    modal.show();
}

// Solicita confirmação antes de enviar a exclusão ao servidor.
function excluirCategoria(id) {
    if (!confirm("Tem certeza de que deseja excluir esta categoria?")) {
        return;
    }

    $.ajax({
        type: "POST",
        url: "/BazarTemTudo/categoria/excluir.php",
        dataType: "json",
        data: { id_categoria: id },
        success: () => {
            $("#linha_categoria_" + id).remove();
            $("#mensagemModal").text("Categoria excluída com sucesso!");
            new bootstrap.Modal('#modal', {}).show();
        },
        error: xhr => {
            const mensagem = xhr.responseJSON && xhr.responseJSON.erro
                ? xhr.responseJSON.erro
                : "Erro ao excluir categoria!";
            $("#mensagemModal").text(mensagem);
            new bootstrap.Modal('#modal', {}).show();
        }
    });
}

function adicionarLinhaNaTabela(categoria) {
    const linha = $("<tr>").attr("id", "linha_categoria_" + categoria.id_categoria);

    $("<td>")
        .attr("id", "categoria_descricao_" + categoria.id_categoria)
        .text(categoria.descricao)
        .appendTo(linha);

    $("<td>").text(categoria.id_categoria).appendTo(linha);

    const acoes = $("<td>");
    $("<button>")
        .attr("type", "button")
        .addClass("btn btn-sm btn-primary me-2")
        .text("Alterar")
        .on("click", () => iniciarAlterar(categoria.id_categoria, categoria.descricao))
        .appendTo(acoes);

    $("<button>")
        .attr("type", "button")
        .addClass("btn btn-sm btn-danger")
        .text("Excluir")
        .on("click", () => excluirCategoria(categoria.id_categoria))
        .appendTo(acoes);

    acoes.appendTo(linha);
    linha.appendTo("#corpoTabela");
}
