<?php
require_once("../comum.php");
require_once(BASE_DIR . "/somenteAutenticado.php");

use Mbelo\Bazar\Banco;

// Recebe e valida o ID da categoria enviado por POST.
$id_categoria = filter_input(INPUT_POST, "id_categoria", FILTER_VALIDATE_INT);

if (!$id_categoria || $id_categoria <= 0) {
    http_response_code(400);
    echo json_encode(["erro" => "ID da categoria inválido."]);
    exit;
}

try {
    $pdo = Banco::obterConexao();
    $ps = $pdo->prepare("DELETE FROM categoria WHERE id_categoria = :id_categoria");
    $ps->bindValue(":id_categoria", $id_categoria, PDO::PARAM_INT);
    $ps->execute();

    if ($ps->rowCount() === 0) {
        http_response_code(404);
        echo json_encode(["erro" => "Categoria não encontrada."]);
        exit;
    }

    http_response_code(200);
    echo json_encode(["sucesso" => true, "id_categoria" => $id_categoria]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["erro" => "Não foi possível excluir a categoria."]);
}
